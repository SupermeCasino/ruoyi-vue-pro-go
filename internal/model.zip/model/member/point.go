package member

import (
	"github.com/wxlbd/ruoyi-mall-go/internal/model"
)

// MemberPointRecord 用户积分记录
// Table: member_point_record
type MemberPointRecord struct {
	ID          int64  `gorm:"primaryKey;autoIncrement;comment:自增主键" json:"id"`
	UserID      int64  `gorm:"column:user_id;not null;comment:用户编号" json:"userId"`
	BizID       string `gorm:"column:biz_id;size:64;comment:业务编码" json:"bizId"`
	BizType     int    `gorm:"column:biz_type;not null;comment:业务类型" json:"bizType"` // MemberPointBizTypeEnum
	Title       string `gorm:"column:title;size:64;not null;comment:积分标题" json:"title"`
	Description string `gorm:"column:description;size:255;default:'';comment:积分描述" json:"description"`
	Point       int    `gorm:"column:point;not null;comment:变动积分" json:"point"`              // 1、正数表示获得积分 2、负数表示消耗积分
	TotalPoint  int    `gorm:"column:total_point;not null;comment:变动后的积分" json:"totalPoint"` // 变动后的积分
	model.TenantBaseDO
}

func (MemberPointRecord) TableName() string {
	return "member_point_record"
}
